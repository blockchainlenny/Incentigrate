# Incentigrate MVP Todos

## Phase 1: Project Setup & Core Structure

- [x] Initialize Next.js + Shadcn/UI project (Theme: Green)
- [x] Install dependencies
- [x] Start development server
- [x] Create basic folder structure for components, services, etc.

## Phase 2: Screen Implementation (UI Shells & Basic Logic)

- [x] **Dashboard Screen:**
    - [x] UI shell based on STEPN/Raydium (progress arc/bar, badge icons placeholder, lively visuals)
    - [x] Display mock $O-Token balance
    - [x] Display mock learning progress (e.g., "2/5 modules completed")
    - [x] Placeholder for NFT/certificate
- [x] **Learning Modules Screen:**
    - [x] UI shell for listing modules (inspired by Kiron.ngo layout)
    - [x] UI shell for a single sample module (inspired by Duolingo - steps, reward claim)
    - [x] "Claim Reward" button (simulated action)
    - [x] Stub for multi-language (e.g., EN/DE text, no actual library yet)
- [x] **Forum Screen:**
    - [x] UI shell for country boards (e.g., Germany, France) - like Reddit
    - [x] Placeholder for "Anonymous Post" button
    - [x] Placeholder UI for X/Telegram integration
- [x] **Wallet & Login:**
    - [x] UI for simulated social login (e.g., "Login with Google" button)
    - [x] Basic wallet view (display mock Solana address, $O-Token balance)
    - [x] Logout button (simulated)
    - [x] Placeholder for "Send/Request" token buttons (disabled)

## Phase 3: Navigation & Backend Simulation

- [x] Implement basic navigation (tab-based or bottom nav with icons)
- [x] Simulate backend logic (mock data/state management within frontend for now):
    - [x] User authentication state (logged in/out)
    - [x] $O-Token balance updates (e.g., after "claiming" reward)
    - [x] Learning module progress tracking

## Phase 4: Solana Integration (Simulated)

- [x] Simulate Solana wallet auto-generation on login
- [x] Simulate $O-Token "airdrop" on registration
- [x] Connect "Claim Reward" to update simulated $O-Token balance

## Phase 5: Styling & Theming

- [x] Apply overall blue/green color theme (inspired by Kiron.ngo)
- [x] Refine UI of each screen based on design references (STEPN, Duolingo, Reddit, Phantom)
- [x] Ensure basic responsiveness

## Phase 6: Placeholders & Future Features

- [x] Add UI stubs/buttons for deferred features:
    - [x] "Add new module"
    - [x] "Add new forum feature" (partially covered by existing forum placeholders)
    - [x] "Marketplace"
    - [x] "NFT certificate uploads/verification"
    - [x] "Governance module"
    - [x] "Partner/NGO dashboard"
    - [x] "Referral mechanism"
    - [x] "Staking/yield"
    - [x] "Premium/paid courses" (Covered by implication, specific button not added for MVP)
- [x] Add placeholder for GDPR consent/info
- [x] Add placeholder for multi-factor auth (Considered out of scope for social login stub for MVP)

## Phase 7: Polishing & Versioning

- [x] Review for basic accessibility
- [x] Create initial project version
- [x] Prepare for multi-language (simple EN/DE text examples)

## Backend (Separate Future Phase - for now, all simulated in frontend)
- [ ] Node.js/Express server setup
- [ ] MongoDB schema design and connection
- [ ] Actual OAuth implementation
- [ ] API endpoints for user data, learning progress, token interactions
