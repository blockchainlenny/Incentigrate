'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  BookMarked, Briefcase, ChevronRight, Code, FileText, Languages, Laptop, TrendingUp,
} from "lucide-react";
import { learningModules } from "@/app/_data/learningModules";
import { useAppContext } from "@/app/contexts/AppContext";

interface LearningModulesListProps {
  onSelectModule: (moduleId: string, moduleTitle: string) => void;
}

// Helper to get the correct Lucide icon component based on string name
const getIconComponent = (iconName: string) => {
  switch (iconName) {
    case "BookMarked": return BookMarked;
    case "TrendingUp": return TrendingUp;
    case "FileText": return FileText;
    case "Briefcase": return Briefcase;
    case "Laptop": return Laptop;
    case "Code": return Code;
    case "Languages": return Languages;
    default: return BookMarked; // Default icon
  }
};

const LearningModulesList = ({ onSelectModule }: LearningModulesListProps) => {
  const { learningProgress } = useAppContext();

  return (
    <div className="container mx-auto p-4 md:p-8 space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-gray-800">Explore Learning Modules</CardTitle>
          <CardDescription className="text-lg text-gray-600">
            Expand your knowledge and skills. Click on a module to start learning.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {learningModules.map((module) => {
            const IconComponent = getIconComponent(module.icon);
            const progress = learningProgress[module.id];
            let statusText = "Not Started";
            if (progress) {
              if (progress.completedSteps === module.totalLessons && module.totalLessons > 0) {
                statusText = progress.claimed ? "Completed & Claimed" : "Completed";
              } else if (progress.completedSteps > 0) {
                statusText = `In Progress (${progress.completedSteps}/${module.totalLessons})`;
              }
            }

            return (
              <Card
                key={module.id}
                className="hover:shadow-md transition-shadow cursor-pointer border border-gray-200 rounded-lg overflow-hidden"
                onClick={() => onSelectModule(module.id, module.title)}
              >
                <div className="flex items-center p-4">
                  <div className="mr-4 p-3 bg-gray-100 rounded-lg">
                    <IconComponent className="h-6 w-6 text-themeBlue" />
                  </div>
                  <div className="flex-grow">
                    <h3 className="text-lg font-semibold text-gray-700 hover:text-themeBlue">{module.title}</h3>
                    <p className="text-sm text-gray-500 mb-1 line-clamp-2">{module.description}</p>
                    <div className="flex items-center text-xs text-gray-400 space-x-2 flex-wrap">
                      <span>{module.category}</span>
                      <span>&bull;</span>
                      <span>{module.totalLessons} lessons</span>
                      <span>&bull;</span>
                      <span>{module.duration}</span>
                      <span>&bull;</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-xs font-medium
                          ${statusText.startsWith("Completed") ? "bg-green-100 text-green-700" : ""}
                          ${statusText.startsWith("In Progress") ? "bg-sky-100 text-sky-700" : ""}
                          ${statusText === "Not Started" ? "bg-gray-100 text-gray-700" : ""}`}
                      >
                        {statusText}
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400 ml-auto flex-shrink-0" />
                </div>
              </Card>
            );
          })}
        </CardContent>
      </Card>
      <div className="text-center mt-6">
        <Button variant="outline" disabled>
          Load More Modules (Coming Soon)
        </Button>
      </div>
    </div>
  );
};

export default LearningModulesList;
