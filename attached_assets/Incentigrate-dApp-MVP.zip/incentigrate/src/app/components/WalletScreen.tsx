'use client';

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LogOut, Wallet, Send, ArrowDownToLine, Copy, AlertCircle, ShieldCheck, KeyRound, Mail } from "lucide-react";
import Image from 'next/image'; // For the Google logo
import React from 'react';
import { useAppContext, LoginType } from "@/app/contexts/AppContext";

// Simple component for wallet icons (could be expanded or made more dynamic)
const WalletIcon = ({ type, className }: { type: string, className?: string }) => {
  if (type === 'phantom') {
    // Placeholder for Phantom Icon - ideally an SVG or actual logo
    return <Image src="https://phantom.app/img/logo.png" alt="Phantom" width={20} height={20} className={`mr-2 ${className}`} />;
  }
  if (type === 'solflare') {
    // Placeholder for Solflare Icon - ideally an SVG or actual logo
    return <KeyRound className={`mr-2 h-5 w-5 ${className}`} /> // Using a generic key icon for now
  }
  if (type === 'google') {
    return <Image src="https://developers.google.com/static/identity/images/branding_guide_do_5.png" alt="Google logo" width={20} height={20} className={`mr-2 ${className}`} />;
  }
  if (type === 'email') {
    return <Mail className={`mr-2 h-5 w-5 ${className}`} />;
  }
  return <Wallet className={`mr-2 h-5 w-5 ${className}`} />;
};


const WalletScreen = () => {
  const { isLoggedIn, login, logout, oTokenBalance, userName, loginType, walletAddress } = useAppContext();

  const handleLogin = (type: LoginType, name?: string) => {
    let addr = `Demo${type?.charAt(0).toUpperCase()}${type?.slice(1)}WalletAddr${Math.random().toString(36).substring(2, 9)}`;
    login(type, name, addr);
  };

  const copyAddress = () => {
    if (walletAddress && navigator.clipboard) {
        navigator.clipboard.writeText(walletAddress)
        .then(() => alert("Address copied to clipboard!"))
        .catch(err => console.error('Failed to copy: ', err));
    } else {
        console.warn("Clipboard API not available or no address to copy.");
        alert("Clipboard API not available or no address to copy.");
    }
  };

  return (
    <div className="container mx-auto p-4 md:p-8 space-y-6 flex flex-col items-center">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <Wallet className="h-12 w-12 mx-auto text-themeBlue mb-2" />
          <CardTitle className="text-2xl font-bold text-gray-800">
            {isLoggedIn && userName ? `${userName}'s Wallet` : "Your Incentigrate Wallet"}
          </CardTitle>
          {!isLoggedIn ? (
            <CardDescription className="text-gray-600">
              Connect your wallet or sign in to continue.
            </CardDescription>
          ) : (
            <CardDescription className="text-gray-600">
              {loginType && `Connected via ${loginType.charAt(0).toUpperCase() + loginType.slice(1)}`}
            </CardDescription>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoggedIn && walletAddress ? (
            <>
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-700 font-medium">Your Wallet Address:</p>
                <div className="flex items-center justify-between">
                    <p className="text-xs md:text-sm text-green-600 break-all">{walletAddress}</p>
                    <Button variant="ghost" size="sm" onClick={copyAddress} title="Copy Address">
                        <Copy className="h-4 w-4 text-green-600" />
                    </Button>
                </div>
                { loginType === 'google' || loginType === 'email' ?
                    <p className="text-xs text-muted-foreground mt-1">(This social wallet was abstracted for you)</p> :
                    <p className="text-xs text-muted-foreground mt-1">(Connected to your Solana wallet)</p>
                }
              </div>

              <div className="p-4 bg-sky-50 border border-sky-200 rounded-lg">
                <p className="text-sm text-sky-700 font-medium">$O-Token Balance:</p>
                <p className="text-2xl font-bold text-sky-600">{oTokenBalance.toLocaleString()} $O</p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <Button variant="outline" disabled className="w-full">
                  <Send className="h-4 w-4 mr-2" /> Send (Soon)
                </Button>
                <Button variant="outline" disabled className="w-full">
                  <ArrowDownToLine className="h-4 w-4 mr-2" /> Request (Soon)
                </Button>
              </div>
              <Button onClick={logout} variant="destructive" className="w-full mt-4">
                <LogOut className="h-4 w-4 mr-2" /> Logout / Disconnect
              </Button>
            </>
          ) : (
            <div className="space-y-3">
              <Button
                onClick={() => handleLogin('phantom', 'Phantom User')}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white shadow-sm flex items-center justify-center"
              >
                <WalletIcon type="phantom" /> Connect Phantom Wallet
              </Button>
              <Button
                onClick={() => handleLogin('solflare', 'Solflare User')}
                className="w-full bg-orange-500 hover:bg-orange-600 text-white shadow-sm flex items-center justify-center"
              >
                <WalletIcon type="solflare" /> Connect Solflare Wallet
              </Button>

              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t"></span>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-white px-2 text-muted-foreground">Or continue with</span>
                </div>
              </div>

              <Button
                onClick={() => handleLogin('google', 'Demo Google User')}
                className="w-full bg-white border-gray-300 hover:bg-gray-50 text-gray-700 shadow-sm flex items-center justify-center"
              >
                <WalletIcon type="google" /> Sign in with Google
              </Button>
              <Button
                onClick={() => handleLogin('email', 'Demo Email User')}
                className="w-full bg-gray-600 hover:bg-gray-700 text-white shadow-sm flex items-center justify-center"
              >
                <WalletIcon type="email" /> Sign in with Email
              </Button>
              <p className="text-xs text-center text-gray-500 pt-2">
                Social sign-ins will auto-generate a secure wallet for you (simulated).
              </p>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex flex-col items-center text-center text-xs text-gray-500 pt-4 border-t">
            <div className="flex items-center text-green-600 mb-1"><ShieldCheck className="h-4 w-4 mr-1"/> Your keys are managed securely.</div>
            <p>Incentigrate is committed to GDPR compliance and data protection.</p>
        </CardFooter>
      </Card>

      {isLoggedIn && (
          <Card className="w-full max-w-md mt-6 bg-yellow-50 border-yellow-200">
            <CardHeader className="flex flex-row items-center space-x-3 pb-3">
                <AlertCircle className="h-6 w-6 text-yellow-600 flex-shrink-0" />
                <div>
                    <CardTitle className="text-lg text-yellow-700">Hackathon Demo Notes</CardTitle>
                </div>
            </CardHeader>
            <CardContent className="text-sm text-yellow-600 space-y-1">
                <p>_ This is a <b>simulated wallet connection</b> for demo purposes.</p>
                <p>_ Wallet addresses and balances are hardcoded based on login type.</p>
                <p>_ In a real app, this would integrate with actual Solana wallet adapters and services like Privy.io or Dynamic.xyz for social logins.</p>
            </CardContent>
          </Card>
      )}
    </div>
  );
};

export default WalletScreen;
