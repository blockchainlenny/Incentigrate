'use client';

import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ThumbsUp, ThumbsDown, MessageSquare, CornerDownRight, X } from "lucide-react";

export interface Comment {
  id: string;
  user: string;
  avatar?: string;
  fallback?: string;
  time: string;
  text: string;
  replies?: Comment[]; // For nested comments
}

export interface Post {
  id: string;
  user: string;
  avatar?: string;
  fallback?: string;
  time: string;
  title: string;
  content: string;
  replies: number; // Count of top-level comments
  upvotes: number;
  category: string; // e.g., 'germany', 'france', 'general'
  comments: Comment[];
}

interface PostDetailViewProps {
  post: Post | null;
  isOpen: boolean;
  onClose: () => void;
}

const PostDetailView: React.FC<PostDetailViewProps> = ({ post, isOpen, onClose }) => {
  if (!post) return null;

  const handleUpvote = () => {
    console.log(`Simulated upvote for post: ${post.id}`);
  };

  const handleDownvote = () => {
    console.log(`Simulated downvote for post: ${post.id}`);
  };

  const handleReplyToPost = () => {
    alert("Simulated reply to post. In a real app, a text input would appear.");
  };

  const handleReplyToComment = (commentId: string) => {
    alert(`Simulated reply to comment ${commentId}.`);
  };

  const renderComments = (comments: Comment[], level = 0) => {
    return comments.map(comment => (
      <div key={comment.id} className={`mt-3 pt-3 ${level > 0 ? 'ml-6 pl-4 border-l border-gray-200' : ''}`}>
        <div className="flex items-start space-x-2.5">
          <Avatar className="w-8 h-8 mt-1">
            <AvatarImage src={comment.avatar} alt={`@${comment.user}`} />
            <AvatarFallback className="text-xs">{comment.fallback || comment.user.substring(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="flex-1 bg-slate-50 p-3 rounded-lg">
            <div className="flex items-center space-x-2 mb-1">
              <span className="font-semibold text-sm text-gray-700">{comment.user}</span>
              <span className="text-xs text-gray-400">&bull;</span>
              <span className="text-xs text-gray-500">{comment.time}</span>
            </div>
            <p className="text-sm text-gray-600 whitespace-pre-wrap">{comment.text}</p>
            <div className="mt-2 flex items-center space-x-3">
              <Button variant="ghost" size="xs" className="text-xs text-gray-500 hover:text-themeBlue" onClick={() => handleReplyToComment(comment.id)}>
                <CornerDownRight className="h-3 w-3 mr-1" /> Reply
              </Button>
              <Button variant="ghost" size="xs" className="text-xs text-gray-500 hover:text-themeGreen">
                <ThumbsUp className="h-3 w-3 mr-1" /> <span className="mr-1">{Math.floor(Math.random() * 10)}</span>
              </Button>
            </div>
          </div>
        </div>
        {comment.replies && comment.replies.length > 0 && renderComments(comment.replies, level + 1)}
      </div>
    ));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="p-6 border-b">
          <DialogTitle className="text-xl md:text-2xl font-bold text-gray-800 leading-tight">{post.title}</DialogTitle>
          <div className="flex items-center space-x-2 text-sm text-gray-500 mt-1 flex-wrap">
            <Avatar className="w-6 h-6">
              <AvatarImage src={post.avatar} alt={`@${post.user}`} />
              <AvatarFallback className="text-xs">{post.fallback || post.user.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <span>Posted by <span className="font-medium text-gray-700">{post.user}</span></span>
            <span className="hidden sm:inline">&bull;</span>
            <span className="block sm:inline mt-1 sm:mt-0">{post.time}</span>
            <span className="hidden sm:inline">&bull;</span>
            <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full text-xs block sm:inline mt-1 sm:mt-0">{post.category}</span>
          </div>
          <DialogClose asChild className="absolute right-3 top-3 sm:right-4 sm:top-4">
            <Button type="button" variant="ghost" size="icon">
              <span className="sr-only">Close</span>
            </Button>
          </DialogClose>
        </DialogHeader>

        <div className="p-6 overflow-y-auto flex-grow">
          <div className="prose prose-sm sm:prose-base max-w-none text-gray-700 whitespace-pre-wrap">
            {post.content}
          </div>

          <div className="mt-4 pt-4 border-t flex items-center space-x-4">
            <Button variant="outline" size="sm" onClick={handleUpvote} className="hover:border-themeGreen hover:text-themeGreen">
              <ThumbsUp className="h-4 w-4 mr-2" /> Upvote ({post.upvotes})
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownvote} className="hover:border-red-500 hover:text-red-500">
              <ThumbsDown className="h-4 w-4 mr-2" /> Downvote
            </Button>
            <Button variant="default" size="sm" onClick={handleReplyToPost} className="bg-themeBlue hover:bg-opacity-90">
              <MessageSquare className="h-4 w-4 mr-2" /> Reply to Post
            </Button>
          </div>

          <div className="mt-6">
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Comments ({post.comments?.length || 0})</h3>
            {post.comments && post.comments.length > 0 ? (
              renderComments(post.comments)
            ) : (
              <p className="text-sm text-gray-500">No comments yet. Be the first to reply!</p>
            )}
          </div>
        </div>

        <DialogFooter className="p-4 border-t sm:justify-start">
          <DialogClose asChild>
            <Button type="button" variant="secondary">
              Close
            </Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default PostDetailView;
