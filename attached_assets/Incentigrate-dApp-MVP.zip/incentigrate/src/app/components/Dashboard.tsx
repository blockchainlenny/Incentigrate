'use client';

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Award, BookOpenText, DollarSign, Gift, Image as ImageIcon, User, TrendingUp, CheckSquare, Link, ArrowRightCircle } from "lucide-react";
import { useAppContext } from "@/app/contexts/AppContext";
import React from 'react';
import { learningModules as allLearningModules } from "@/app/_data/learningModules";
// import { integrationStepsGermany } from "@/app/_data/integrationSteps"; // No longer needed for dashboard display
import { ViewType } from "@/app/page";

interface DashboardProps {
  navigateTo: (view: ViewType, moduleId?: string, moduleTitle?: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ navigateTo }) => {
  const { isLoggedIn, oTokenBalance, learningProgress, userName, loginType, walletAddress } = useAppContext(); // Removed integrationStepStatus

  // Learning Modules Progress
  const modulesTracked = Object.keys(learningProgress).length;
  let totalCompletedModules = 0;
  let totalLessonsInTrackedModules = 0;
  let totalCompletedLessonsInTrackedModules = 0;
  for (const moduleId in learningProgress) {
    const progress = learningProgress[moduleId];
    totalLessonsInTrackedModules += progress.totalSteps;
    totalCompletedLessonsInTrackedModules += progress.completedSteps;
    if (progress.completedSteps === progress.totalSteps && progress.totalSteps > 0) {
      totalCompletedModules++;
    }
  }
  const totalProgramModules = allLearningModules.length > 0 ? allLearningModules.length : 5;
  const overallLearningProgressPercentage = modulesTracked > 0 && totalProgramModules > 0 ? (totalCompletedModules / totalProgramModules) * 100 : 0;

  // Integration Steps Progress REMOVED from display for now

  if (!isLoggedIn) {
    return (
      <div className="container mx-auto p-4 md:p-8 text-center">
        <Card className="max-w-lg mx-auto">
            <CardHeader>
                <User className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                <CardTitle className="text-xl">Welcome to Incentigrate!</CardTitle>
                <CardDescription>Please log in via the Wallet screen to see your dashboard and start your learning journey.</CardDescription>
            </CardHeader>
            <CardContent>
                <Button onClick={() => navigateTo('wallet')} className="bg-themeBlue hover:bg-opacity-90">
                    Go to Wallet to Login
                </Button>
            </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-8 space-y-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-themeBlue">Welcome back, {userName}!</h1>
        {loginType && (
          <p className="text-sm text-gray-500 flex items-center">
            <Link className="h-4 w-4 mr-1 text-gray-400" />
            Connected via: <span className="font-medium ml-1">{loginType.charAt(0).toUpperCase() + loginType.slice(1)}</span>
            {walletAddress && <span className="text-xs text-gray-400 ml-2 truncate">({walletAddress.substring(0,6)}...{walletAddress.substring(walletAddress.length - 4)})</span>}
          </p>
        )}
        <p className="text-gray-600 mt-1">Here’s an overview of your progress and rewards.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4"> {/* Changed to 2 cols, or adjust as needed */}
        <Card className="bg-emerald-50 border-emerald-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-emerald-700">$O-Token Balance</CardTitle>
            <DollarSign className="h-5 w-5 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">{oTokenBalance.toLocaleString()} $O</div>
            <p className="text-xs text-muted-foreground pt-1">Your available rewards</p>
          </CardContent>
        </Card>

        <Card className="bg-sky-50 border-sky-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-sky-700">Learning Modules Progress</CardTitle>
            <BookOpenText className="h-5 w-5 text-sky-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-sky-600">{totalCompletedModules} / {totalProgramModules} Modules Completed</div>
            <Progress value={overallLearningProgressPercentage} className="mt-2 h-3 bg-sky-100" indicatorClassName="bg-sky-500" />
            <p className="text-xs text-muted-foreground pt-1">
                {totalCompletedLessonsInTrackedModules} lessons completed.
            </p>
          </CardContent>
        </Card>

        {/* Integration Steps Progress Card REMOVED */}
        {/* Achievements Card can be brought back if simple */}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Your Active Learning Modules</CardTitle>
          <CardDescription>
            Click on a module to continue or explore all modules in the Learning tab.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {modulesTracked > 0 ? (
            Object.entries(learningProgress).map(([id, progress]) => {
              const moduleDetails = allLearningModules.find(m => m.id === id);
              const title = moduleDetails?.title || `Module ${id}`;
              return (
              <div
                key={id}
                className="flex justify-between items-center p-3 bg-slate-50 rounded-md hover:bg-slate-200 cursor-pointer transition-colors"
                onClick={() => navigateTo('single_module', id, title)}
              >
                <div>
                  <h4 className="font-semibold text-themeBlue hover:underline">{title}</h4>
                  <p className="text-sm text-muted-foreground">
                    Status: {progress.completedSteps}/{progress.totalSteps} lessons completed {progress.claimed ? '(Reward Claimed)' : ''}
                  </p>
                </div>
                <ArrowRightCircle className={`h-6 w-6 ${progress.completedSteps === progress.totalSteps ? 'text-themeGreen' : 'text-themeBlue'}`} />
              </div>
            )})
          ) : (
            <div className="text-center text-gray-500 py-4">
              <p className="mb-2">No learning modules started yet. </p>
              <Button onClick={() => navigateTo('module_list')} className="bg-themeGreen hover:bg-opacity-90">
                Go to Learning Tab!
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Active Integration Steps section REMOVED */}

      <Card className="border-dashed border-gray-300">
        <CardHeader>
          <CardTitle className="text-xl">NFT Certificates & Verifications</CardTitle>
          <CardDescription>Your achievements, verified on the blockchain. (Coming Soon)</CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <ImageIcon className="h-16 w-16 text-gray-300 mx-auto mb-2" />
          <p className="text-muted-foreground">Completed modules will issue verifiable NFT certificates here.</p>
          <button className="mt-4 px-4 py-2 bg-gray-200 text-gray-500 rounded-md cursor-not-allowed" disabled>
            View Certificates (Coming Soon)
          </button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle className="text-xl">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button className="p-3 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors text-sm font-medium disabled:opacity-50" disabled>Add New Module</button>
            <button className="p-3 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors text-sm font-medium disabled:opacity-50" disabled>Marketplace</button>
            <button className="p-3 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors text-sm font-medium disabled:opacity-50" disabled>Governance</button>
            <button className="p-3 bg-orange-100 text-orange-700 rounded-lg hover:bg-orange-200 transition-colors text-sm font-medium disabled:opacity-50" disabled>Refer a Friend</button>
            <button className="p-3 bg-teal-100 text-teal-700 rounded-lg hover:bg-teal-200 transition-colors text-sm font-medium disabled:opacity-50 md:col-span-2" disabled>Partner/NGO Dashboard (Soon)</button>
            <button className="p-3 bg-pink-100 text-pink-700 rounded-lg hover:bg-pink-200 transition-colors text-sm font-medium disabled:opacity-50 md:col-span-2" disabled>Staking & Yield (Soon)</button>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
