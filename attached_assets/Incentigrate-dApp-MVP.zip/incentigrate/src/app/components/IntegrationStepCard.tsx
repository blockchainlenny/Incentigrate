'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox"; // Assuming Checkbox is added
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, Circle, ExternalLink, FileText, Briefcase, BookOpen, Users, Home, Palette, Lightbulb, Star, AlertTriangle } from 'lucide-react';
import { IntegrationStep, StepCategory, OfficialStatus } from "@/app/_data/integrationSteps";
import { useAppContext } from "@/app/contexts/AppContext";

interface IntegrationStepCardProps {
  step: IntegrationStep;
  onToggleStep: (stepId: string) => void;
  onToggleSubTask: (stepId: string, subTaskId: string) => void;
  onViewDetails: (step: IntegrationStep) => void;
  isCompleted: boolean;
  completedSubTasks: number;
  // language: 'en' | 'de'; // To show correct language for title/desc if needed here
}

const getCategoryIcon = (category: StepCategory) => {
  switch (category) {
    case "Legal & Admin": return FileText;
    case "Language & Education": return BookOpen;
    case "Work & Profession": return Briefcase;
    case "Housing": return Home;
    case "Social Integration": return Users;
    case "Daily Life & Culture": return Palette;
    case "Health & Wellbeing": return Lightbulb; // Or Heart, Smile etc.
    case "Long-term Integration": return Star;
    default: return FileText;
  }
};

const getCategoryColor = (category: StepCategory): string => {
  switch (category) {
    case "Legal & Admin": return "border-blue-500";
    case "Language & Education": return "border-green-500";
    case "Work & Profession": return "border-purple-500";
    case "Housing": return "border-orange-500";
    case "Social Integration": return "border-pink-500";
    case "Daily Life & Culture": return "border-yellow-500";
    case "Health & Wellbeing": return "border-teal-500";
    case "Long-term Integration": return "border-indigo-500";
    default: return "border-gray-300";
  }
};

const IntegrationStepCard: React.FC<IntegrationStepCardProps> = ({
  step,
  onToggleStep,
  onToggleSubTask, // Will be used if details are shown within card
  onViewDetails,
  isCompleted,
  completedSubTasks
  // language
}) => {
  const CategoryIcon = getCategoryIcon(step.category);
  const borderColorClass = getCategoryColor(step.category);
  const title = step.title; // Assuming EN for now, will use language prop later
  const description = step.description; // Assuming EN for now

  const totalSubTasks = step.subTasks?.length || 0;
  const subTaskProgress = totalSubTasks > 0 ? (completedSubTasks / totalSubTasks) * 100 : (isCompleted ? 100 : 0);

  return (
    <Card className={`shadow-md hover:shadow-lg transition-shadow border-l-4 ${isCompleted ? 'bg-green-50/50 border-green-400' : borderColorClass }`}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <div className="flex items-center text-xs text-gray-500 mb-1">
              <CategoryIcon className="h-4 w-4 mr-1.5" />
              <span>{step.category}</span>
              <span className="mx-1.5">&bull;</span>
              <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${step.officialStatus === 'official' ? 'bg-sky-100 text-sky-700' : 'bg-gray-100 text-gray-700'}`}>{step.officialStatus}</span>
            </div>
            <CardTitle
              className="text-lg font-semibold cursor-pointer hover:text-themeBlue leading-tight"
              onClick={() => onViewDetails(step)}
            >
              {title}
            </CardTitle>
          </div>
          <Checkbox
            id={`step-${step.id}`}
            checked={isCompleted}
            onCheckedChange={() => onToggleStep(step.id)}
            className="ml-4 flex-shrink-0 h-6 w-6 rounded data-[state=checked]:bg-themeGreen data-[state=checked]:text-primary-foreground"
            aria-label={`Mark step ${title} as complete`}
          />
        </div>
      </CardHeader>
      <CardContent className="pb-4 text-sm text-gray-600 cursor-pointer" onClick={() => onViewDetails(step)}>
        <p className="line-clamp-2">{description}</p>
        {totalSubTasks > 0 && (
          <div className="mt-3">
            <div className="flex justify-between items-center text-xs text-gray-500 mb-0.5">
              <span>Sub-tasks progress:</span>
              <span>{completedSubTasks} / {totalSubTasks}</span>
            </div>
            <Progress value={subTaskProgress} className="h-1.5" indicatorClassName={isCompleted ? "bg-green-500" : "bg-themeBlue"} />
          </div>
        )}
        {!totalSubTasks && isCompleted && (
             <p className="text-xs text-green-600 mt-2 font-medium">Step completed!</p>
        )}
      </CardContent>
      <CardFooter className="text-xs pt-3 border-t flex justify-between items-center">
        <div className="text-gray-500">
          <span>{step.difficulty} &bull; {step.estimatedTime}</span>
          {step.points && <span className="ml-2 font-semibold text-yellow-600">{step.points} XP</span>}
        </div>
        <Button variant="outline" size="sm" onClick={() => onViewDetails(step)} className="text-xs">
            View Details
        </Button>
      </CardFooter>
    </Card>
  );
};

export default IntegrationStepCard;
