'use client';

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, CheckCircle2, ChevronLeft, BookOpen, Sparkles, Award, Flag, Clock } from "lucide-react";
import { AlertCircle } from "lucide-react"; // Import AlertCircle
import React, { useState, useEffect } from 'react';
import { useAppContext } from "@/app/contexts/AppContext";
import { learningModules } from "@/app/_data/learningModules";

interface SingleModuleViewProps {
  moduleId: string;
  moduleTitle: string;
  onBackToList: () => void;
  totalRewardAmount?: number;
}

const SingleModuleView = ({ moduleId, moduleTitle, onBackToList, totalRewardAmount = 50 }: SingleModuleViewProps) => {
  const { isLoggedIn, claimReward, updateModuleProgress, learningProgress } = useAppContext();
  const [currentLanguage, setCurrentLanguage] = useState("EN");

  // Find the module data
  const moduleData = learningModules.find(module => module.id === moduleId);

  // If module not found, use default steps
  const moduleSteps = moduleData?.lessons || [];
  const moduleTotalReward = moduleData?.reward || totalRewardAmount;

  // Setup state for module progress
  const moduleProgress = learningProgress[moduleId];
  const completedStepsCount = moduleProgress?.completedSteps || 0;
  const totalStepsCount = moduleSteps.length;
  const progressPercentage = totalStepsCount > 0 ? (completedStepsCount / totalStepsCount) * 100 : 0;

  // Calculate earned Points (was XP)
  const earnedPoints = moduleSteps
    .filter((_, index) => index < completedStepsCount)
    .reduce((sum, step) => sum + step.xp, 0); // Assuming xp field in Lesson interface is for points
  const totalPointsAvailable = moduleSteps.reduce((sum, step) => sum + step.xp, 0);

  const moduleCompletelyFinished = completedStepsCount === totalStepsCount && totalStepsCount > 0;
  const isRewardClaimed = moduleProgress?.claimed || false;

  // Handle completing a lesson
  const handleStepCompletionToggle = (stepId: number) => {
    // Find index of the step in the module steps array
    const stepIndex = moduleSteps.findIndex(step => step.id === stepId);

    if (stepIndex === -1) return;

    // A step can only be completed if it's the next one in sequence
    if (stepIndex === completedStepsCount) {
      // Update the global context with the new progress
      updateModuleProgress(moduleId, completedStepsCount + 1, totalStepsCount);
    }
  };

  // Handle claiming the reward
  const handleClaimReward = () => {
    if (!isLoggedIn) {
      alert("Please log in to claim rewards.");
      return;
    }
    if (moduleCompletelyFinished && !isRewardClaimed) {
      claimReward(moduleId, moduleTotalReward);
    }
  };

  // Access control - require login
  if (!isLoggedIn) {
    return (
      <div className="container mx-auto p-4 md:p-8 text-center">
        <AlertCircle className="h-12 w-12 mx-auto text-red-500 mb-4" />
        <h2 className="text-xl font-semibold mb-2">Access Denied</h2>
        <p className="mb-4 text-gray-600">You need to be logged in to view and interact with learning modules.</p>
        <Button onClick={onBackToList}>Go Back</Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-8 space-y-6">
      <Button variant="outline" onClick={onBackToList} className="mb-4">
        <ChevronLeft className="h-4 w-4 mr-2" />
        {currentLanguage === "EN" ? "Back to Modules" : "Zurück zu den Modulen"}
      </Button>

      <Card className="shadow-lg overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-themeGreen to-themeBlue p-6">
          <div className="flex justify-between items-center mb-2">
            <CardTitle className="text-3xl font-bold text-white">{moduleData?.title || moduleTitle}</CardTitle>
            <div className="flex space-x-2">
              <Button
                size="sm"
                variant={currentLanguage === "EN" ? "secondary" : "outline"}
                onClick={() => setCurrentLanguage("EN")}
                className="text-xs"
              >
                <Flag className="h-3 w-3 mr-1" /> EN
              </Button>
              <Button
                size="sm"
                variant={currentLanguage === "DE" ? "secondary" : "outline"}
                onClick={() => setCurrentLanguage("DE")}
                className="text-xs"
              >
                <Flag className="h-3 w-3 mr-1" /> DE
              </Button>
            </div>
          </div>
          <CardDescription className="text-sky-100">
            {currentLanguage === "EN"
              ? moduleData?.description || `Complete all lessons and quizzes to earn your reward and certificate for module: ${moduleId}.`
              : `Schließe alle Lektionen und Quizze ab, um deine Belohnung und dein Zertifikat für Modul: ${moduleId} zu erhalten.`}
          </CardDescription>
        </CardHeader>

        <CardContent className="p-6">
          <div className="mb-6">
            <div className="flex justify-between items-center mb-1">
              <span className="text-sm font-medium text-gray-600">
                {currentLanguage === "EN"
                  ? "Overall Progress"
                  : "Gesamtfortschritt"}
                : {completedStepsCount}/{totalStepsCount}{" "}
                {currentLanguage === "EN" ? "lessons" : "Lektionen"}
              </span>
              <span className="text-sm font-medium text-yellow-500">
                {earnedPoints}/{totalPointsAvailable} Points
              </span>
            </div>
            <Progress
              value={progressPercentage}
              className="h-3 bg-gray-200"
              indicatorClassName="bg-gradient-to-r from-yellow-400 to-orange-500"
            />
          </div>

          <div className="space-y-3">
            {moduleSteps.map((step, index) => {
              const isStepCompleted = index < completedStepsCount;
              const isStepClickable = !isStepCompleted && index === completedStepsCount;

              return (
                <Card
                  key={step.id}
                  className={`p-4 transition-all hover:shadow-md
                    ${isStepCompleted ? "bg-green-50 border-green-200" : "bg-white border-gray-200"}
                    ${isStepClickable ? "opacity-100 cursor-pointer ring-2 ring-blue-500 ring-offset-1" : "opacity-60 cursor-not-allowed"}`}
                  onClick={() => isStepClickable ? handleStepCompletionToggle(step.id) : null}
                >
                  <div className="flex flex-col md:flex-row md:justify-between">
                    <div className="flex items-start mb-3 md:mb-0">
                      {isStepCompleted ? (
                        <CheckCircle2 className="h-6 w-6 text-green-500 mr-3 mt-1 flex-shrink-0" />
                      ) : (
                        <BookOpen
                          className={`h-6 w-6 mr-3 mt-1 flex-shrink-0 ${
                            isStepClickable ? "text-blue-500" : "text-gray-400"
                          }`}
                        />
                      )}
                      <div>
                        <h4
                          className={`font-semibold ${
                            isStepCompleted
                              ? "text-gray-700 line-through"
                              : "text-gray-800"
                          }`}
                        >
                          {step.title}
                        </h4>
                        <p className="text-sm text-gray-600 mt-1">{step.description}</p>
                      </div>
                    </div>
                    <div className="flex ml-9 md:ml-0 space-x-3 md:flex-col md:space-x-0 md:space-y-1 md:items-end flex-shrink-0">
                      <div className="flex items-center text-yellow-600">
                        <Sparkles className="h-4 w-4 mr-1" /> {step.xp} Points
                      </div>
                      <div className="flex items-center text-blue-600">
                        <Clock className="h-4 w-4 mr-1" /> {step.estimatedMinutes} min
                      </div>
                    </div>
                  </div>

                  {isStepClickable && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <p className="text-xs text-gray-500">{step.contentSummary}</p>
                      <Button
                        className="mt-2 bg-blue-500 hover:bg-blue-600"
                        size="sm"
                        onClick={() => handleStepCompletionToggle(step.id)}
                      >
                        Complete Lesson
                      </Button>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        </CardContent>

        <CardFooter className="bg-gray-50 p-6 flex flex-col items-center space-y-3">
          {moduleCompletelyFinished ? (
            isRewardClaimed ? (
              <div className="text-center">
                <CheckCircle className="h-12 w-12 text-themeGreen mx-auto mb-2" />
                <p className="font-semibold text-themeGreen">
                  {currentLanguage === "EN"
                    ? "Module Completed & Reward Claimed!"
                    : "Modul abgeschlossen & Belohnung beansprucht!"}
                </p>
                <p className="text-sm text-gray-500">
                  {currentLanguage === "EN"
                    ? `Your ${moduleTotalReward} $O-Tokens have been added to your wallet.`
                    : `Deine ${moduleTotalReward} $O-Token wurden deinem Wallet hinzugefügt.`}
                </p>
              </div>
            ) : (
              <Button
                size="lg"
                className="w-full bg-themeGreen hover:bg-opacity-90 text-white shadow-lg transform hover:scale-105 transition-transform"
                onClick={handleClaimReward}
                disabled={!isLoggedIn}
              >
                <Award className="h-5 w-5 mr-2" />{" "}
                {currentLanguage === "EN"
                  ? `Claim ${moduleTotalReward} $O Reward!`
                  : `${moduleTotalReward} $O Belohnung beanspruchen!`}
              </Button>
            )
          ) : (
            <p className="text-sm text-gray-500">
              {currentLanguage === "EN"
                ? "Complete all lessons to claim your reward."
                : "Schließe alle Lektionen ab, um deine Belohnung zu beanspruchen."}
            </p>
          )}
          <p className="text-xs text-gray-400 text-center pt-2">
            {currentLanguage === "EN"
              ? "Rewards are simulated for this demo."
              : "Belohnungen sind für diese Demo simuliert."}
          </p>
        </CardFooter>
      </Card>
    </div>
  );
};

export default SingleModuleView;
