'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MessageSquare, PlusCircle, Send, UserCircle, Twitter, Users, ThumbsUp, ExternalLink } from "lucide-react";
import React, { useState } from 'react';
import PostDetailView, { Post } from '@/app/components/PostDetailView';

const mockPostsData: { [key: string]: Post[] } = {
  germany: [
    {
      id: "g1", user: "Ahmad_K", avatar: "https://randomuser.me/api/portraits/men/32.jpg", fallback: "AK", time: "3h ago",
      title: "Looking for advice: Best way to open a bank account in Berlin?",
      content: "Hello everyone! I just arrived in Berlin and need to open a bank account. It seems a bit complicated with all the different banks and options (Sparkasse, N26, Commerzbank etc.).\n\nDoes anyone have recent experience or recommendations for a bank that is relatively easy for newcomers to set up an account with? Specifically, I'm looking for something with low fees if possible, and English-speaking customer service would be a huge plus.\n\nAny tips on required documents (Meldebescheinigung I have, anything else?) or specific branches that are known to be helpful would be greatly appreciated! Thanks in advance!",
      replies: 2, upvotes: 28, category: 'germany',
      comments: [
        { id: "gc1-1", user: "MariaS", avatar: "https://randomuser.me/api/portraits/women/44.jpg", fallback: "MS", time: "2h ago", text: "Hi Ahmad! I had a good experience with N26. It was all online and in English. You just need your passport and Meldebescheinigung. Super quick!" },
        { id: "gc1-2", user: "LukasM", avatar: "https://randomuser.me/api/portraits/men/33.jpg", fallback: "LM", time: "1h ago", text: "Sparkasse is also good, they have many branches. Some staff speak English, especially in central areas. They might require more paperwork initially though.", replies: [{id: "gc1-2-1", user: "Ahmad_K", avatar: "https://randomuser.me/api/portraits/men/32.jpg", fallback: "AK", time: "30m ago", text: "Thanks Maria and Lukas! N26 sounds convenient. I will check it out. Good to know about Sparkasse too!"}] }
      ]
    },
    {
      id: "g2", user: "Fatima88", avatar: "https://randomuser.me/api/portraits/women/35.jpg", fallback: "F8", time: "8h ago",
      title: "German Language Tandem Partner in Hamburg gesucht (B1 Level)",
      content: "Hallo zusammen! Ich bin Fatima und wohne seit kurzem in Hamburg. Ich suche eine/n Tandempartner/in, um mein Deutsch (aktuell B1 Niveau) zu verbessern. Ich spreche Arabisch und Englisch als Muttersprache und helfe gerne dabei auch weiter!\n\nIch interessiere mich für Kultur, Kochen und Spaziergänge. Wäre toll, wenn sich jemand meldet!",
      replies: 1, upvotes: 15, category: 'germany',
      comments: [
        { id: "gc2-1", user: "AnjaK", avatar: "https://randomuser.me/api/portraits/women/36.jpg", fallback: "AK", time: "5h ago", text: "Hallo Fatima, ich hätte Interesse! Ich lerne gerade Arabisch (Anfänger) und mein Deutsch ist Muttersprache. Hamburg ist toll für Spaziergänge! Schreib mir gerne eine Nachricht." }
      ]
    }
  ],
  france: [
    {
      id: "f1", user: "OmarFR", avatar: "https://randomuser.me/api/portraits/men/37.jpg", fallback: "OF", time: "1d ago",
      title: "Understanding the French OFPRA process - any experiences?",
      content: "Bonjour à tous, I am currently going through the OFPRA asylum application process in France and would like to connect with others who have experience with it. \n\nWhat are some key things to prepare for the interview? How long did it generally take for you to receive a decision? Any advice on finding legal support or translators if needed?\n\nIt feels quite overwhelming, so any shared experiences or tips would be incredibly helpful. Merci!",
      replies: 1, upvotes: 22, category: 'france',
      comments: [
        { id: "fc1-1", user: "SophieB", avatar: "https://randomuser.me/api/portraits/women/38.jpg", fallback: "SB", time: "18h ago", text: "Hi Omar, the wait can be long, so be patient. For the interview, be honest and as detailed as possible. Organizations like Cimade or France Terre d'Asile can offer legal help. Good luck!" }
      ]
    }
  ],
  general: [
    {
      id: "gen1", user: "IncentiAdmin", avatar: "/logo.png", fallback: "IA", time: "3d ago",
      title: "Welcome to the Incentigrate Community Forum!",
      content: "Hello everyone and a warm welcome to the Incentigrate Community Forum!\n\nThis space is for you to:\n*   Ask questions and share experiences related to integration, learning, and daily life.\n*   Find support from fellow community members.\n*   Connect with people in your new country or those on a similar journey.\n*   Offer help and advice to others.\n\nPlease remember to be respectful, kind, and constructive in all your interactions. Our goal is to build a supportive and empowering community for everyone.\n\nFeel free to introduce yourselves in the comments below or start a new topic in the relevant country board!\n\nHappy connecting!\n- The Incentigrate Team",
      replies: 1, upvotes: 45, category: 'general',
      comments: [
        { id: "genc1-1", user: "NewUser99", avatar: "https://randomuser.me/api/portraits/lego/1.jpg", fallback: "NU", time: "2d ago", text: "This is great! Happy to be here and looking forward to connecting!" }
      ]
    }
  ]
};

type CountryBoard = keyof typeof mockPostsData;

const ForumScreen = () => {
  const [activeBoard, setActiveBoard] = React.useState<CountryBoard>("germany");
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [isPostDetailOpen, setIsPostDetailOpen] = useState(false);

  const handlePostClick = (post: Post) => {
    setSelectedPost(post);
    setIsPostDetailOpen(true);
  };

  const handleClosePostDetail = () => {
    setIsPostDetailOpen(false);
    setSelectedPost(null);
  };

  return (
    <div className="container mx-auto p-4 md:p-8 space-y-6">
      <Card className="shadow-lg">
        <CardHeader className="border-b">
          <div className="flex flex-col md:flex-row justify-between md:items-center space-y-3 md:space-y-0">
            <div className="mb-3 md:mb-0">
              <CardTitle className="text-2xl md:text-3xl font-bold text-gray-800">Community Forum</CardTitle>
              <CardDescription className="text-md md:text-lg text-gray-600">
                Connect, share, and support each other.
              </CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <a
                href="https://x.com/Incentigrate/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2 text-xs md:text-sm"
              >
                <Twitter className="h-4 w-4 mr-1 md:mr-2 text-[#1DA1F2]" /> X (Twitter)
                <ExternalLink className="h-3 w-3 ml-1.5 text-gray-400" />
              </a>
              <a
                href="https://t.me/+jHqcnGMSCkoxZjJi"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2 text-xs md:text-sm"
              >
                <Send className="h-4 w-4 mr-1 md:mr-2 text-[#0088cc]" /> Telegram
                <ExternalLink className="h-3 w-3 ml-1.5 text-gray-400" />
              </a>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <Tabs defaultValue="germany" onValueChange={(value) => setActiveBoard(value as CountryBoard)} className="w-full">
            <div className="flex flex-col md:flex-row justify-between items-center mb-4 space-y-3 md:space-y-0">
              <TabsList className="flex-wrap h-auto md:h-10">
                <TabsTrigger value="general">General</TabsTrigger>
                <TabsTrigger value="germany">Germany</TabsTrigger>
                <TabsTrigger value="france">France</TabsTrigger>
                <TabsTrigger value="other" disabled>More (Soon)</TabsTrigger>
              </TabsList>
              <div className="flex space-x-2">
                <Button variant="default" className="text-xs md:text-sm" disabled title="Feature coming soon">
                  <PlusCircle className="h-4 w-4 mr-1 md:mr-2" /> New Post
                </Button>
                <Button variant="outline" disabled className="text-xs md:text-sm">
                  <UserCircle className="h-4 w-4 mr-1 md:mr-2" /> Anonymous (Soon)
                </Button>
              </div>
            </div>

            {Object.keys(mockPostsData).map((board) => (
              <TabsContent key={board} value={board}>
                {mockPostsData[board as CountryBoard].length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    <MessageSquare className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                    <p>No posts in this board yet.</p>
                    <p className="text-sm">Be the first to share your thoughts!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {mockPostsData[board as CountryBoard].map((post) => (
                      <Card key={post.id} className="hover:shadow-md transition-shadow">
                        <CardHeader className="pb-3 cursor-pointer" onClick={() => handlePostClick(post)}>
                          <div className="flex items-start space-x-3">
                            <Avatar className="mt-1 flex-shrink-0">
                              <AvatarImage src={post.avatar} alt={`@${post.user}`} />
                              <AvatarFallback>{post.fallback || post.user.substring(0, 2).toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div className="flex-grow">
                              <div className="flex items-center space-x-2">
                                <span className="font-semibold text-gray-700 text-sm">{post.user}</span>
                                <span className="text-xs text-gray-400">&bull;</span>
                                <span className="text-xs text-gray-500">{post.time}</span>
                              </div>
                              <CardTitle className="text-lg mt-1 leading-tight hover:text-themeBlue">{post.title}</CardTitle>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pb-3 cursor-pointer" onClick={() => handlePostClick(post)}>
                          <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">{post.content}</p>
                        </CardContent>
                        <CardFooter className="text-xs text-gray-500 flex justify-between items-center pt-3 border-t">
                          <div className="flex space-x-3 md:space-x-4">
                            <button className="hover:text-themeBlue flex items-center"><MessageSquare className="h-3 w-3 md:h-4 md:w-4 mr-1" /> {post.replies} Replies</button>
                            <button className="hover:text-themeGreen flex items-center"><ThumbsUp className="h-3 w-3 md:h-4 md:w-4 mr-1" /> {post.upvotes} Upvotes</button>
                          </div>
                          <Button variant="ghost" size="sm" className="text-xs text-themeBlue hover:text-themeBlue hover:bg-blue-50" onClick={() => handlePostClick(post)}>Read More</Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      <Card className="mt-6 bg-sky-50 border-sky-200">
        <CardHeader>
          <CardTitle className="text-xl text-sky-700">Moderation & Community Guidelines</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-sky-600">
          <p>Our community forum is a place for support and constructive dialogue. Please ensure your contributions are respectful and adhere to our guidelines. Moderation tools are in place to maintain a safe environment.</p>
          <p className="mt-2"><em>(Moderation features and detailed guidelines will be implemented soon.)</em></p>
        </CardContent>
      </Card>

      {selectedPost && (
        <PostDetailView
          post={selectedPost}
          isOpen={isPostDetailOpen}
          onClose={handleClosePostDetail}
        />
      )}
    </div>
  );
};

export default ForumScreen;
