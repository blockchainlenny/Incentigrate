// ... existing code ... <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="p-4 sm:p-6 border-b sticky top-0 bg-background z-10">
          // ... content of DialogHeader ...
        </DialogHeader>

        <div className="p-4 sm:p-6 overflow-y-auto flex-grow">
          // ... scrollable content ...
        </div>

        {/* Footer - removed sticky, ensure it's part of the flex column correctly */}
        <DialogFooter className="p-4 border-t sm:justify-end bg-background">
          <DialogClose asChild>
            <Button type="button" variant="secondary">Close</Button>
          </DialogClose>
        </DialogFooter>
// ... rest of component
