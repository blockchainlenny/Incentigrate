'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button"; // Keep for potential future use
import { useAppContext } from '@/app/contexts/AppContext';
import { ListChecks } from 'lucide-react';

const IntegrationJourneyScreen = () => {
  const { isLoggedIn, userName } = useAppContext();

  // If not logged in, show a prompt to log in.
  // The navigateTo function would be needed if we have a login button here.
  // For now, users are expected to log in via the Wallet screen.
  if (!isLoggedIn) {
    return (
      <div className="container mx-auto p-4 md:p-8 text-center">
        <Card className="max-w-lg mx-auto">
            <CardHeader>
                <ListChecks className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                <CardTitle className="text-xl">Your Integration Journey</CardTitle>
                <CardDescription>Please log in to track your integration steps and progress.</CardDescription>
            </CardHeader>
            <CardContent>
                <p className="text-sm text-gray-500">Login via the Wallet screen to begin.</p>
            </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-8 space-y-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-themeBlue">My Integration Path - Germany</h1>
        <p className="text-gray-600">Track your official and unofficial steps for settling in Germany, {userName}.</p>
      </div>

      <Card>
        <CardHeader>
            <CardTitle className="text-lg">Feature Coming Soon!</CardTitle>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground">
                This section will soon provide a structured list of integration steps, helping you navigate your journey in Germany.
                You'll be able to track your progress, access resources for each step, and earn rewards.
            </p>
            <div className="mt-4 p-3 border rounded-md bg-slate-50">
                <h4 className="font-semibold text-gray-700">Example of a Future Step: Register Residence (Anmeldung)</h4>
                <p className="text-xs text-muted-foreground">Category: Legal & Admin | Status: To Do</p>
                <Button size="sm" className="mt-2" variant="outline" disabled>View Details (Soon)</Button>
            </div>
             <div className="mt-3 p-3 border rounded-md bg-slate-50">
                <h4 className="font-semibold text-gray-700">Example of another Future Step: Open Bank Account</h4>
                <p className="text-xs text-muted-foreground">Category: Legal & Admin | Status: To Do</p>
                <Button size="sm" className="mt-2" variant="outline" disabled>View Details (Soon)</Button>
            </div>
        </CardContent>
      </Card>

      <Card className="bg-sky-50 border-sky-200">
        <CardHeader>
            <CardTitle className="text-xl text-sky-700">Your Journey Map (Concept)</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-sky-600">
            <p>We envision a visual map here, showing your progress through different stages of integration, like a journey through Germany, unlocking new areas as you complete key steps!</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default IntegrationJourneyScreen;
